
API_ID = 20045757 #не, трогать! 
API_HASH = "7d3ea0c0d4725498789bd51a9ee02421" # не, трогать! 
SESSION_NAME = "us5677b"
PLUGIN_DIR = "plugins"