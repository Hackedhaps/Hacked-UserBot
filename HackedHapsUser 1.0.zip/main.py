
import os
import glob
import asyncio
import importlib
from telethon import TelegramClient
from config import API_ID, API_HASH, SESSION_NAME, PLUGIN_DIR

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
loaded_plugins = {}

async def load_plugins():
    plugin_files = glob.glob(os.path.join(PLUGIN_DIR, "*.py"))
    print(f"Найдено плагинов: {len(plugin_files)}")

    for plugin_file in plugin_files:
        plugin_name = os.path.splitext(os.path.basename(plugin_file))[0]
        try:
            print(f"Загружаем плагин: {plugin_name}")
            module = importlib.import_module(f"{PLUGIN_DIR}.{plugin_name}")
            loaded_plugins[plugin_name] = module
            if hasattr(module, "setup"):
                # setup — синхронная функция, вызываем напрямую
                module.setup(client)
            print(f"Плагин {plugin_name} успешно загружен.")
        except Exception as e:
            print(f"Ошибка при загрузке плагина {plugin_name}: {e}")

async def main():
    print("Запускаем юзербота...")
    await client.start()
    print("Юзербот запущен! Загружаю плагины...")
    await load_plugins()
    print("Юзербот работает. Ожидание сообщений...")

    # Ждём навечно
    await client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())