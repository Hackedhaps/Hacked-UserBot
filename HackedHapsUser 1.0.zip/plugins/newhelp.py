from telethon import events
import sys
import os
import asyncio
import time
from telethon.errors.rpcerrorlist import MessageNotModifiedError

RESTART_TIME_FILE = "restart_time.tmp"
MAX_VALID_ELAPSED = 30  # максимум секунд для показа времени перезапуска

async def restart_handler(event):
    if not event.out:
        return

    start_time = time.monotonic()
    await event.edit("♻️ Перезапускаю бота...")

    await asyncio.sleep(1)  # пауза для отображения сообщения

    with open(RESTART_TIME_FILE, "w") as f:
        f.write(str(start_time))

    python = sys.executable
    os.execv(python, [python] + sys.argv)

async def help_handler(event):
    if not event.out:
        return

    elapsed_text = ""
    if os.path.exists(RESTART_TIME_FILE):
        try:
            with open(RESTART_TIME_FILE, "r") as f:
                start_time = float(f.read())
            elapsed = time.monotonic() - start_time
            if 0 < elapsed < MAX_VALID_ELAPSED:
                elapsed_text = f"\n\n✅ <b>Бот перезагружен, заняло {elapsed:.2f} секунд.</b>"
            os.remove(RESTART_TIME_FILE)
        except Exception:
            try:
                os.remove(RESTART_TIME_FILE)
            except Exception:
                pass

    help_text = (
        "✨ <b>1 модулей доступно, 0 скрыто:</b>\n\n"
        "> help помощь.\n\n"
        "📜 <b>Доступные команды:</b>\n"
        "`.help` — показать помощь\n"
        "`.about` — информация о сервере и работе UserBot\n"
        "`.restart` — перезапустить бота\n"
        "`.info` — информация о Hacked haps UserBot"
        + elapsed_text
    )

    current_text = event.message.message  # исходный текст сообщения без форматирования

    if current_text != help_text:
        try:
            await event.edit(help_text, parse_mode="html")
        except MessageNotModifiedError:
            pass  # Игнорируем ошибку, если сообщение не изменилось
        except Exception as e:
            await event.reply(f"❌ Ошибка при отправке сообщения: {e}")

async def info_handler(event):
    if not event.out:
        return

    info_text = (
        "🛡️ <b>Информация о Hacked haps UserBot</b>\n\n"
        "📌 Версия: <b>1.0 (beta)</b>\n"
        "👨‍💻 Разработчик: <a href=\"https://t.me/NewsHacked\">@NewsHacked</a>\n"
        "🚀 Спасибо за использование!\n"
    )

    current_text = event.message.message

    if current_text != info_text:
        try:
            await event.edit(info_text, parse_mode="html", link_preview=False)
        except MessageNotModifiedError:
            pass
        except Exception as e:
            await event.reply(f"❌ Ошибка при отправке сообщения: {e}")

def setup(client):
    client.add_event_handler(
        restart_handler,
        events.NewMessage(pattern=r"^\.(restart|reboot)(?:\s|$)")
    )
    client.add_event_handler(
        help_handler,
        events.NewMessage(pattern=r"^\.(help)(?:\s|$)")
    )
    client.add_event_handler(
        info_handler,
        events.NewMessage(pattern=r"^\.(info)(?:\s|$)"